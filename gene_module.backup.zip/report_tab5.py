#%%
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.manifold import MDS
from sklearn.manifold import TSNE

import matplotlib.pyplot as plt

X = np.load('gene_data/data/p2_unsupervised/X.npy')

print(f'shape of X {X.shape}')
X_log = np.log2(X+1)

max = X_log[:,0].max()
print(f'max X_log in col0: {max}')

#%%
#-------
# Part 1
# Visualization
# (1)

# PCA
pca_log = PCA().fit(X_log)
# plt.plot(range(1, X.shape[0]+1), np.cumsum(pca_log.explained_variance_ratio_), color="blue", label="log")
# plt.legend()
# plt.show()
z = pca_log.transform(X_log)
plt.scatter(z[:,0],z[:,1])
plt.title('PCA of X_log')
plt.show()

# MDS
mds_class=MDS(n_components=2)
mds=mds_class.fit_transform(X_log)
print(mds_class.stress_)
plt.scatter(mds[:,0],mds[:,1])
plt.title('MDS of X_log')
plt.show()

#%%
# T SNE
z_tsne_class = TSNE(n_components=2,perplexity=200)
z_tsne=z_tsne_class.fit_transform(z[:,0:50])
print(z_tsne_class.kl_divergence_)
plt.scatter(z_tsne[:,0],z_tsne[:,1])
plt.title('TSNE of X_log')
plt.show()
# %%
kmeans = KMeans(3, tol=1e-6) 
kmeans.fit(z[:,0:50])
plt.scatter(z_tsne[:,0],z_tsne[:,1], c=kmeans.labels_, cmap=plt.cm.brg)
plt.title('TSNE, kmeans cluster colors from PCA')
# %%
plt.scatter(z[:,0],z[:,1], c=kmeans.labels_, cmap=plt.cm.brg)
plt.title('PCA of X_log')
plt.show()
# %%
N = 20
all_kmeans = [i for i in range(N)]
for i in range(N):
    cur_kmeans = KMeans(i+2)
    cur_kmeans.fit(z_tsne)
    #print("Num clusters", i+2, "Inertia:", cur_kmeans.inertia_)
    all_kmeans[i] = cur_kmeans
plt.plot([i+2 for i in range(N)], [all_kmeans[i].inertia_ for i in range(N)])
plt.title('KMeans Inertia vs Num Clusters')
plt.show()
# %%
kmeans = KMeans(7, tol=1e-6) 
kmeans.fit(z_tsne)
plt.scatter(z_tsne[:,0],z_tsne[:,1], c=kmeans.labels_, cmap=plt.cm.brg)
plt.title('TSNE with 7 Clusters')
plt.show()

# %%
# Logistic Regression
np.random.seed(317)
perm = np.random.permutation(X_log.shape[0])
n_train = int(4/5*X_log.shape[0])

X_train = X_log[perm[:n_train]]
y_train = kmeans.labels_[perm[:n_train]]
X_test = X_log[perm[n_train:]]
y_test = kmeans.labels_[perm[n_train:]]

from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
log_reg = LogisticRegression(penalty="l2",multi_class="ovr").fit(X_train,y_train)
print(f' train score {log_reg.score(X_train,y_train)}')
print(f' test score {log_reg.score(X_test,y_test)}')
# %%
coef_sums = np.sum(np.abs(log_reg.coef_),axis=0)
sort_inds = np.argsort(coef_sums)
sort_inds = sort_inds[::-1] # reverse order
best_feature_inds = sort_inds[:100]

# %%
Xp2_test = np.log2(np.load('gene_data/data/p2_evaluation/X_test.npy') +1)
Xp2_train = np.log2(np.load('gene_data/data/p2_evaluation/X_train.npy') +1)
yp2_test = np.load('gene_data/data/p2_evaluation/y_test.npy')
yp2_train = np.load('gene_data/data/p2_evaluation/y_train.npy')
log_reg_p2 = LogisticRegression(penalty="l2",max_iter=1000, multi_class="ovr").fit(Xp2_train[:,best_feature_inds],yp2_train)
p2_score = log_reg_p2.score(Xp2_test[:,best_feature_inds],yp2_test)
print(f' p2 score {p2_score}')

# %%
perm100 = np.random.permutation(log_reg.coef_.shape[1])
rand_feature_inds = perm100[:100]

coef_vars = np.var(log_reg.coef_, axis=0)
coef_vars_sort_inds = np.argsort(coef_vars)
highest_var_feature_inds = coef_vars_sort_inds[-100:]

highest_var = coef_vars[highest_var_feature_inds]
_, bins, _ = plt.hist(highest_var, bins=100, range=[0,.0009], alpha=0.7, label='highest 100')

rand_var = coef_vars[rand_feature_inds]
plt.hist(rand_var, bins=bins, alpha=0.7, label='random 100')
plt.legend()
plt.title('Histogram of feature variances')
# %%

# highest var
log_reg_p2 = LogisticRegression(penalty="l2",max_iter=1000, multi_class="ovr").fit(Xp2_train[:,highest_var_feature_inds],yp2_train)
p2_score = log_reg_p2.score(Xp2_test[:,highest_var_feature_inds],yp2_test)
print(f' highest variance features: score {p2_score}')

# random features
log_reg_p2 = LogisticRegression(penalty="l2",max_iter=1000, multi_class="ovr").fit(Xp2_train[:,rand_feature_inds],yp2_train)
p2_score = log_reg_p2.score(Xp2_test[:,rand_feature_inds],yp2_test)
print(f' random features: score {p2_score}')
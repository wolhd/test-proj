
#include "Config.h"
#include "stdio.h"
#include <iostream>

using std::cout;
using std::endl;

int main(int argc, char* argv[]) {
	char* filename = NULL;
	if (argc > 1) {
		filename = argv[1];
	}
	Config c(filename);
	printf("vfAddress: %s\n", c.getVfAddress().c_str());
	printf("vfPort: %s\n", c.getVfPort().c_str());
	cout << "quAddress: " << c.getQuAddress().length() << endl;
	return 0;
}

#ifndef __CONFIG_H__
#define __CONFIG_H__

#include <fstream>
#include <sstream>
#include <map>

typedef std::map<std::string, std::string> ConfigMap;

class Config {
public:
	Config(const char* filename) {
		if (filename == NULL) return;
		std::ifstream infile(filename);
		std::string line;
		while(std::getline(infile, line)) {
			std::istringstream is_line(line);
			std::string key;
			if (std::getline(is_line, key, '=')) {
                std::string value;
                if (key[0] == '#')
                    continue;
                if (std::getline(is_line, value))
                    configMap_[key] = value;
            }
        }
	}
	std::string getVfAddress() {
		return configMap_["vfAddress"];
	}
	std::string getVfPort() {
		return configMap_["vfPort"];
	}
	std::string getQuAddress() {
		return configMap_["quAddress"];
	}
	std::string getQuPort() {
		return configMap_["quPort"];
	}

private:
	ConfigMap configMap_;

};

#endif

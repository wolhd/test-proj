#include "UdpServer.h"

#include <cstdio>
#include <iostream>
#include <cstring>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


using std::cout;
using std::endl;

bool UdpServer::init(std::string server_port_str) {
	// socket address used for the server
	struct sockaddr_in server_address;
	memset(&server_address, 0, sizeof(server_address));
	server_address.sin_family = AF_INET;


    int server_port;
    sscanf(server_port_str.c_str(), "%d", &server_port);
	// htons: host to network short: transforms a value in host byte
	// ordering format to a short value in network byte ordering format
	server_address.sin_port = htons(server_port);

	// htons: host to network long: same as htons but to long
	server_address.sin_addr.s_addr = htonl(INADDR_ANY);

	// create a UDP socket, creation returns -1 on failure
	if ((socketfd_ = socket(PF_INET, SOCK_DGRAM, 0)) < 0) {
		cout << "could not create socket for port: " << server_port_str << endl;
		return false;
	}

	// bind it to listen to the incoming connections on the created server
	// address, will return -1 on error
	if ((bind(socketfd_, (struct sockaddr *)&server_address,
	          sizeof(server_address))) < 0) {
		cout << "could not bind socket for port: " << server_port_str << endl;
		return false;
	}
	return true;
}

int UdpServer::read(uint8_t* buffer, int length) {
	int len = recvfrom(socketfd_, buffer, sizeof(buffer), 0, NULL, NULL);
	cout << "recvfrom() returned num bytes: " << len << endl;
	return len;
}

#pragma once

#include <stdint.h>
#include <string>

class UdpServer {

public:

	UdpServer(): socketfd_(-1) {}

	bool init(std::string server_port_str);

	int read(uint8_t* buffer, int length);

	bool hasSocket() { return socketfd_ >= 0; }

private:

    int socketfd_;

};

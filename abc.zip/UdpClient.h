#ifndef __UDPCLIENT_H__
#define __UDPCLIENT_H__

#include <iostream>
#include <cstdio>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

using std::cout;
using std::endl;

class UdpClient {

public:

	UdpClient(): socketfd_(-1) {}

	bool init(std::string server_name, std::string server_port_str) {
    	if (server_name.size() == 0 || server_port_str.size() == 0) return false;
    	memset(&server_address_, 0, sizeof(server_address_));
    	server_address_.sin_family = AF_INET;
    	int ret = inet_pton(AF_INET, server_name.c_str(), &server_address_.sin_addr);
        if (ret != 1) {
            cout << "inet_pton returned error for server_name: " << server_name << endl;
            return false;
        }
    	// htons: port in network order format
        int server_port;
        sscanf(server_port_str.c_str(), "%d", &server_port);
    	server_address_.sin_port = htons(server_port);

    	// open socket
    	socketfd_ = socket(PF_INET, SOCK_DGRAM, 0);
    	if (socketfd_ < 0) {
    		cout << "Could not create socket for: " << server_name << " " << server_port_str << endl;
            return false;
    	}
        return true;
    }

	void send(const void* buffer, int buf_len) {
		int len = sendto(socketfd_, buffer, buf_len, 0,
		           (struct sockaddr*)&server_address_, sizeof(server_address_));
	    if (len != buf_len) {
	        printf("send() size [%d] not same as buffer size [%d]\n", len, buf_len);
	    }
	}

    ~UdpClient() {
        if (socketfd_ != 0) {
            close(socketfd_);
        }
    }

private:

    int socketfd_;

    struct sockaddr_in server_address_;
};

#endif

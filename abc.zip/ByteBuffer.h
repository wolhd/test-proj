
#ifndef __BYTE_BUFFER_H__
#define __BYTE_BUFFER_H__


#include "stdint.h"

class ByteBuffer
{
public:

    ByteBuffer(void);

    /** @return The number of bytes in the buffer past the index */
    uint16_t getBytesRemaining(void) const;

    /**
     * Points the object to the buffer to work with.
     * @param[in] buffer  The buffer to work with
     * @param[in] length  The size of the buffer in bytes.
     */
    void setBuffer(uint8_t* buffer, uint16_t length);

    /** @return The buffer storage. */
    uint8_t* getBuffer(void) { return mBuffer; }

    /** @return The length (max size) of the buffer */
    uint16_t getLength(void) const { return mLength; }

    /**
     * Sets the index back to the beginning of the buffer, effectivly emptying
     * the buffer.
     */
    void resetIndex(void);

    /**
     * Move the index foward.
     * @param[in] amount  The amount to move the index.
     */
    void advanceIndex(uint16_t amount);

    /**
     * Sets the position of the index.
     * @param[in] pos New position of the index.
     */
    void setIndex(uint16_t index);

    /**
     * @return The number of bytes written to the buffer.
     */
    uint16_t getPosition(void) const { return mIndex; }

    /**
     * Writes a byte to the buffer at the current index location and advances
     * the index.
     * @param[in] data  The data to write to buffer.
     */
    void write(int8_t data);

    /**
     * Writes a byte to the buffer at the current index location and advances
     * the index.
     * @param[in] data  The data to write to buffer.
     */
    void write(uint8_t data);

    /**
     * Writes a uint16_t to the buffer at the current index location and
     * advances the index.
     * @param[in] data  The data to write to buffer.
     */
    void write(uint16_t data);

    /**
     * Writes an int16_t to the buffer at the current index location and
     * advances the index.
     * @param[in] data  The data to write to buffer.
     */
    void write(int16_t data);

    /**
     * Writes a uint16_t to the buffer at the specified location
     * @param[in] data  The data to write to buffer.
     * @param[in] index Index where the write starts
     */
    void write(uint16_t data, uint16_t index);

    /**
     * Writes a uint32_t value to the buffer at the current index location and
     * advances the index.
     * @param[in] data  The data to write to buffer.
     */
    void write(uint32_t data);

    void write(int32_t data);

    /**
     * Writes a uint32_t to the buffer at the specified location
     * @param[in] data  The data to write to buffer.
     * @param[in] index Index where the write starts
     */
    void write(uint32_t data, uint16_t index);

    /**
     * Writes a buffer of data to the buffer
     * @param[in] data  The data to write
     * @param[in] length  Number of bytes to write
     */
    void write(const char* data, uint16_t length);
    
    /**
     * Writes a float value to the buffer at the current index and advances
     * the index.
     * @param[in] v  The value to write.
     */
    void write(float v);

    void write(void* data, uint16_t index, uint16_t numBytes);

    void read(int8_t* v);
    void read(uint8_t* v);
    void read(uint16_t* v);
    void read(int16_t* v);
    void read(uint32_t* v);
    void read(int32_t* v);
    void read(float* v);
    bool read(void* dest, uint16_t index, uint16_t length);
    bool read(void* dest, uint16_t length);


protected:

    /** The buffer to work with. */
    uint8_t* mBuffer;

    /** The size of the buffer in bytes */
    uint16_t mLength;

    /** The current position in the buffer */
    uint16_t mIndex;
};

#endif


#include "UdpClient.h"
#include "UdpServer.h"
#include "ByteBuffer.h"
#include <thread>
#include <string>
#include <ctime>
#include <chrono>
#include <vector>

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>

/**
 * next:
 *
 */

void writeVfPacket(ByteBuffer& bb, uint16_t frame, uint16_t packet, uint16_t row, uint16_t col,
		uint8_t* vdata, int len) {

}

using namespace cv;
using std::vector;

vector<uint8_t> buildImg;

void matRowsToVec(Mat mat, int rowStart, int numRows, vector<uint8_t>& vec) {
	int s1 = vec.size();
	for (int i = rowStart; i < (rowStart + numRows); ++i) {
		int size1 = vec.size();
		vec.insert(vec.end(), mat.ptr<uint8_t>(i), mat.ptr<uint8_t>(i)+mat.cols);
		int size2 = vec.size();
		if ((size2-size1) * mat.elemSize() != 640)
			cout << ">>>> unexpected size of data in one row" << endl;
	}
	int s2 = vec.size();
	cout << "s1 " << std::to_string(s1) << ", s2 " << std::to_string(s2) << endl;
	if (s2-s1 != numRows * 640)
		cout << ">>> unexpected size of data for 6 rows: " << std::to_string(s2-s1) << endl;
}
Mat vecToMat(vector<uint8_t> vec, int rows, int cols) {
	Mat m = Mat(rows, cols, CV_8UC1);
	memcpy(m.data, vec.data(), vec.size());
	return m;
}

void displayImg(Mat& mat) {
    imshow( "Display window", mat );
    waitKey(20*1000);
}
void sendToServer(vector<uint8_t>& vec) {
	uint8_t* buf = vec.data();
	int len = vec.size();
	cout << "buildImg size " << buildImg.size() << ", incoming vec size " << len << endl;
	if (buildImg.size() < 640*480) {
		buildImg.insert(buildImg.end(), buf, buf + len);
	}
	if (buildImg.size() >= 640*480) {
		Mat mat = vecToMat(buildImg, 480, 640);
		cout << "display img size " << mat.size() << endl;
		displayImg(mat);
		buildImg.clear();
	}
	cout << "new buildImg size: " << buildImg.size() << endl;

}
void sendImg(Mat& mat) {
	cout << "send img mat, size " << mat.size() << endl;
	for (int r = 0; r < 480; r+=6) {
		vector<uint8_t> vec;
		matRowsToVec(mat, r, 6, vec);
		sendToServer(vec);
	}
}

void read_pngs(const char* directory) {
	std::string dir = "/home/dchen/Hits/testFiles/test_vid_pngs/";


    namedWindow( "Display window", WINDOW_AUTOSIZE );
    long long currtime = (long long) time(NULL);
    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();

    int startPng = 30;
    int endPng = 35; // 150

    for (int i = startPng; i < endPng; i++) {

    	std::string imgfile = dir + "out" + std::to_string(i) +".png";
        Mat image;
        image = imread( imgfile, IMREAD_GRAYSCALE );
        if( image.empty() )
        {
            cout <<  "Could not open or find the image" << std::endl ;
            return;
        }
        cout << ">>> read img type: " << image.type() << endl;

//        displayImg(image);
        sendImg(image);


        if (i%20 == 0) {
        	std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
        	auto diff = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin).count();
        	cout << "diff " << diff << endl;
        	double idou = i;
        	double fps = idou / diff * 1000;
        	cout << "millisec based fps: " << std::to_string(fps) << endl;
        }
    }
    long long currtime2 = (long long) time(NULL);
    float fps = 149 / (currtime2 - currtime);
    cout << "fps: " << fps << endl;


}



// create VfServer that reads vfPacket


// pass one msg to server
void simpleUdpTest() {
	UdpClient uclient;
	std::string addr = "127.0.0.1";
	std::string port = "19001";
	uclient.init(addr, port);
	UdpServer userver;
	userver.init(port);

	std::string txt = "123456";
	uclient.send(txt.c_str(), txt.size());

	uint8_t readBuf[100];
	int len = userver.read(&readBuf[0], 100);


}

int main() {
	read_pngs("nothing");
}


#include "ByteBuffer.h"
#include <string.h>

ByteBuffer::ByteBuffer(void)
    : mBuffer(0),
      mLength(0),
      mIndex(0)
{

}

/******************************************************************************
 ******************************************************************************/
uint16_t ByteBuffer::getBytesRemaining(void) const
{
    return (mLength - mIndex);
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::setBuffer(uint8_t* buffer, uint16_t length)
{
    mBuffer = buffer;
    mLength = length;
    mIndex = 0;
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::resetIndex(void)
{
    mIndex = 0;
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::advanceIndex(uint16_t amount)
{
    if ((mIndex + amount) < mLength)
    {
        mIndex += amount;
    }
    else
    {
        mIndex = mLength;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::setIndex(uint16_t index)
{
    if (index < mLength)
    {
        mIndex = index;
    }
    else
    {
        mIndex = mLength;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(int8_t data)
{
    if (mIndex < mLength)
    {
        mBuffer[mIndex++] = (uint8_t)data;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(uint8_t data)
{
    if (mIndex < mLength)
    {
        mBuffer[mIndex++] = data;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(uint16_t data)
{
    if (mIndex < (mLength + sizeof(uint16_t)))
    {
        *((uint16_t*)&mBuffer[mIndex]) = data;
        mIndex += sizeof(uint16_t);
    }
}

/******************************************************************************
******************************************************************************/
void ByteBuffer::write(int16_t data)
{
    if (mIndex < (mLength + sizeof(int16_t)))
    {
        *((int16_t*)&mBuffer[mIndex]) = data;
        mIndex += sizeof(int16_t);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(uint16_t data, uint16_t index)
{
    if (index < (mLength + sizeof(uint16_t)))
    {
        *((uint16_t*)&mBuffer[index]) = data;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(uint32_t data)
{
    if (mIndex < (mLength + sizeof(uint32_t)))
    {
        *((uint32_t*)&mBuffer[mIndex]) = data;
        mIndex += sizeof(uint32_t);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(int32_t data)
{
    if (mIndex < (mLength + sizeof(int32_t)))
    {
        *((int32_t*)&mBuffer[mIndex]) = data;
        mIndex += sizeof(int32_t);
    }
}


/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(uint32_t data, uint16_t index)
{
    if (index < (mLength + sizeof(uint32_t)))
    {
        *((uint32_t*)&mBuffer[index]) = data;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(float v)
{
    if (mIndex < (mLength + sizeof(float)))
    {
        *((float*)&mBuffer[mIndex]) = v;
        mIndex += sizeof(float);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(const char* data, uint16_t length)
{
    if (mIndex < (mLength + length))
    {
        memcpy(&mBuffer[mIndex], data, length);
        mIndex += length;
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::write(void* data, uint16_t index, uint16_t numBytes)
{
    if ((index + numBytes) < mLength)
    {
        memcpy(&mBuffer[index], data, numBytes);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(int8_t* v)
{
    if (mIndex < (mLength + sizeof(int8_t)))
    {
        *v = (int8_t)mBuffer[mIndex++];
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(uint8_t* v)
{
    if (mIndex < (mLength + sizeof(uint8_t)))
    {
        *v = mBuffer[mIndex++];
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(uint16_t* v)
{
    if (mIndex < (mLength + sizeof(uint16_t)))
    {
        *v = *((uint16_t*)&mBuffer[mIndex]);
        mIndex += sizeof(uint16_t);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(int16_t* v)
{
    if (mIndex < (mLength + sizeof(int16_t)))
    {
        *v = *((int16_t*)&mBuffer[mIndex]);
        mIndex += sizeof(int16_t);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(uint32_t* v)
{
    if (mIndex < (mLength + sizeof(uint32_t)))
    {
        *v = *((uint32_t*)&mBuffer[mIndex]);
        mIndex += sizeof(uint32_t);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(int32_t* v)
{
    if (mIndex < (mLength + sizeof(int32_t)))
    {
        *v = *((int32_t*)&mBuffer[mIndex]);
        mIndex += sizeof(int32_t);
    }
}

/******************************************************************************
 ******************************************************************************/
void ByteBuffer::read(float* v)
{
    if (mIndex < (mLength + sizeof(float)))
    {
        *v = *((float*)&mBuffer[mIndex]);
        mIndex += sizeof(float);
    }
}

/******************************************************************************
 ******************************************************************************/
bool ByteBuffer::read(void* dest, uint16_t index, uint16_t length)
{
    bool result = false;

    if ((index + length) <= mLength)
    {
        memcpy(dest, &mBuffer[index], length);
        result = true;
    }

    return result;
}

/******************************************************************************
 ******************************************************************************/
bool ByteBuffer::read(void* dest, uint16_t length)
{
    bool result = false;

    if ((mIndex + length) <= mLength)
    {
        memcpy(dest, &mBuffer[mIndex], length);
        mIndex += length;
        result = true;
    }

    return result;
}
